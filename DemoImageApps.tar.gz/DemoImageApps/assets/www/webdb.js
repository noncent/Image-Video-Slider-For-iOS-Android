/**************************************************
 *
 * @type WebSQL Library for Use HTML5 Database.
 * @author Neeraj-Singh
 * @version 1.0
 * @copyright Global Space Tech Pvt Ltd @ 2012
 * @license Free for Personal Use, not Commercial
 *
 **************************************************/
var web = {};
web.sql = {};
web.sql.db = null;
var imgPath = "themes/images/";
// Set database name here
var dbName = "demo_media_pro";
// Set function for open db
webSqlOpen = function(){
    var dbSize = 5 * 1024 * 1024; // 5MB
    web.sql.db = openDatabase(dbName, "1.0", "Demo Media Manager", dbSize);
}
// set function for create table
createTable = function(){
    var db = web.sql.db;
    db.transaction(function(rs){
        rs.executeSql("CREATE TABLE IF NOT EXISTS cat(cat_id INTEGER PRIMARY KEY, cat_name TEXT)", []);
        rs.executeSql("CREATE TABLE IF NOT EXISTS product(product_id INTEGER PRIMARY KEY, cat_id INTEGER, product_name TEXT, product_info TEXT)", []);
        rs.executeSql("CREATE TABLE IF NOT EXISTS media(product_id INTEGER, media_id INTEGER PRIMARY KEY, media_type TEXT, media_path TEXT, media_info TEXT)", []);
        rs.executeSql("CREATE TABLE IF NOT EXISTS history(history_id INTEGER PRIMARY KEY, play_time TEXT, pause_time TEXT, actual_time TEXT, media_name TEXT, status INTEGER)", []);
    });
}
// Set Meta Data
function loadData(){
    var db = web.sql.db;
    var cat_data = new Array("Presentation", "Mission", "Vision", "Products", "ContactUs", "History");
    // Insert meta cat data from array list
    db.transaction(function(rs){
        for (i = 0; i < cat_data.length; i++) {
            rs.executeSql("INSERT INTO cat(cat_name) VALUES (?)", [cat_data[i]]);
        }
        // end meta cat data //
        // product list array
        product_data = [];
        product_data['cat_id'] = new Array("1", "2", "3", "4", "5", "6");
        product_data['product_name'] = new Array("Company", "2012", "Go Ahead", "Social", "Feel Free", "Get History");
        product_data['product_info'] = new Array("Demo", "Demo", "Demo", "Demo", "Demo", "Media History");
        for (i = 0; i < product_data['cat_id'].length; i++) {
            rs.executeSql("INSERT INTO product(cat_id, product_name, product_info) VALUES (?,?,?)", [product_data['cat_id'][i], product_data['product_name'][i], product_data['product_info'][i]], onSqlSuccess, onSqlError);
        }// end product data //
        // here is meta media data
        for (i = 1; i <= 12; i++) {
            product_id = 1;
            media_type = "1";
            media_path = i + "_pic.jpg";
            media_info = "This is " + i + " slide";
            rs.executeSql("INSERT INTO media(product_id, media_type, media_path, media_info) VALUES (?,?,?,?)", [product_id, media_type, media_path, media_info]);
        }
        // reload window after insert all meta data in sql
        window.location.reload();
    });
}

// Save play/pause history
function setHistory(play_time, pause_time, actual_time, media_name){
    var db = web.sql.db;
    db.transaction(function(rs){
        rs.executeSql("INSERT INTO history(play_time, pause_time, actual_time, media_name, status) VALUES (?,?,?,?,?)", [play_time, pause_time, actual_time, media_name, 1]);
    });
}

// if sql error found
onSqlError = function(rs, e){
    alert("There has been an error: " + e.message);
}
// if sql run success
onSqlSuccess = function(rs, e){
    // re-render the data.
    return true;
}
// Custome Function For Get All Product
function fetch_product(cat_id, index){
    var db = web.sql.db;
    var sout = db.transaction(function(rs){
        // get product via cat_id
        rs.executeSql('SELECT * FROM product WHERE cat_id="' + cat_id + '"', [], function(rs, results){
            var sOutput = '<ul>';
            var len = results.rows.length;
            for (i = 0; i < len; i++) {
                var row = results.rows.item(i);
                sOutput += '<li id="' + row.product_id + '">' +
                row.product_name +
                '</li>';
            }
            sOutput += '</ul>';
            $("#acc" + index).after(sOutput);
        }, onSqlError);
    });
    return sout;
}

// Custome Function For Get All Cat ID
function fetch_cat(){
    var db = web.sql.db;
    html = $("#accordion");
    db.transaction(function(rs){
        // cat_id and cat_name
        rs.executeSql('SELECT * FROM cat', [], function(rs, results){
            var len = results.rows.length;
            for (i = 0; i < len; i++) {
                var row = results.rows.item(i);
                html.append('<li><div id="acc' + i + '">' + row.cat_name +
                '</div>');
                fetch_product(row.cat_id, i);
                html.append("</li>");
            }
        });
    });
}

// Custome Function For Get All Media
function fetch_media(product_id){
    var db = web.sql.db;
    if (product_id != 0) {
        db.transaction(function(rs){
            rs.executeSql('SELECT * FROM media WHERE product_id=' + product_id, [], appendMedia, onSqlError);
        });
    }
    else {
        db.transaction(function(rs){
            rs.executeSql('SELECT * FROM history WHERE status=1', [], showHistory, onSqlError);
        });
    }
}

// Custome Function For Show Media History
function getHistory(){
    var db = web.sql.db;
    db.transaction(function(rs){
        rs.executeSql('SELECT * FROM history WHERE status=1', [], showHistory, onSqlError);
    });
    
}


// Custome function for show Media play/pause History
function showHistory(rs, results){
    var htmlOutput = '';
    htmlOutput += '<tr>    <th> Sr. No.   </th>    <th>  Play Time  </th>    <th>  Pause Time  </th>    <th> Actual Time </th> <th>  Media Name  </th>    <th> Action   </th></tr>';
    var len = results.rows.length;
    for (i = 0; i < len; i++) {
        var row = results.rows.item(i);
        htmlOutput += '<tr>    <td>  ' + row.history_id + '  </td>    <td>  ' + row.play_time + '  </td>    <td>  ' + row.pause_time + '  </td>    <td> ' + row.actual_time + '</td>  <td>  ' + row.media_name + '  </td>    <td>  <a href="javascript:;" id="' + row.history_id + '" rel="history" class="delete">Delete</a>  </td></tr>';
    }
    $('.history').html(htmlOutput);
}

// Custome Function For Reset Media History
function resetHistory(){
    var db = web.sql.db;
    db.transaction(function(rs){
        rs.executeSql('DELETE history', [], "", onSqlError);
    });
}

// Custome Function For display thumbnails
function appendMedia(rs, results){
    var thumbs = "";
    // set image path folder
    var imgPath = "themes/images/";
    html = $(".galleria-thumbnails");
    html.html("");
    var len = results.rows.length;
    for (i = 0; i < len; i++) {
        var thumbsrow = results.rows.item(i);
        thumbs += '<img class="img_thumb" title="' + thumbsrow.media_info +
        '"  alt="' +
        thumbsrow.media_info +
        '"  src="' +
        imgPath +
        thumbsrow.media_path +
        '" height="40"	  width="60"/>';
    }
    html.html("");
    html.html(thumbs);
    thumbs = "";
    $('.history').prev("p").html('<input type="checkbox" name="show_history" id="show_history"/> Show Real Time Play/Pause History. | <a href="javascript:void(0);" onclick="getHistory();">[Refresh Data]</a> | <a href="javascript:void(0);" onclick="hideMe();">[Hide Data]</a>');
    // reload galleria script
    callBackGalleria();
}

// Custome Function For Delete Records with ID
deleteMe = function deleteRecord(id, table){
    var db = web.sql.db;
    db.transaction(function(rs){
        rs.executeSql('UPDATE ' + table + ' SET status=0 WHERE history_id=?', [id], onSqlSuccess, onSqlError);
    });
    table == 'history' ? getHistory() : '';
}
// Hide History Table as Toggle
hideMe = function(){
    $(".history").slideToggle('slow');
}
// Reload galleria script
function callBackGalleria(){
    // Initialize Galleria
    $('#galleria').galleria();
}

// start function on Document load
$(document).ready(function(){
    $("#accordion ul li").live('click', function(){
        var product_id = $(this).attr("id");
        var li_text = $(this).html();
        li_text == "Get History" ? getHistory() : product_id = product_id;
        fetch_media(product_id);
        
    });
    
    // While user want to delete record
    $("a.delete").live('click', function(){
        // call delete function with id and table name
        deleteMe($(this).attr('id'), $(this).attr('rel'));
    });
});
// Custome Function For Start all Services
function init(){
    // Open WebSQL
    webSqlOpen();
    // Create Sql Table
    createTable();
    // Check Data exist or not in Table
    initCheckDb();
    // Get all Cat for Left Menu
    fetch_cat();
}

// here we are checking that, record already exist or not in table. if no record found then load meta data on page load, otherwise leave it
function initCheckDb(){
    var db = web.sql.db;
    var sout = db.transaction(function(rs){
        // check no of rows
        rs.executeSql('SELECT * FROM cat', [], function(rs, results){
            var len = results.rows.length;
            if (len != 0) {
                return false;
            }
            else {
                loadData();
            }
        }, onSqlError);
    });
}

// Capture Current Time
function clickTime(){
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds()
    var clickTime = hours + ":" + minutes + ":" + seconds;
    return clickTime;
}
