// This will be hardcoded content for now.
function getVideoToutAsset(assetId, videoIdentifier) {
	// assetIds
	// desktopVideoUri returns the videoUri for desktop.
	// iphoneOnDemandUri reutrns the On Demand video Uri
	// iphoneLiveUri returns the Live video Uri
	// logoPNG returns the logo image 58 x 33
	// desktopPoster 852 x 482 image

	var assetDesktopLogoImage = '';
	var assetDesktopVideoUri = '';
	var assetVideoTitle = '';
	var assetVideoDescription = '';
	var assetIphoneVideoUri = '';
	var assetDesktopPoster = '';
	var assetDesktopThumbnail = '';
	var assetIphoneLogoImage = '';
	var assetIphonePoster = '';
	var assetChannel = '';

	if (1 == 2) {

		// Do nothing.
	} else if (videoIdentifier == "T1") {
		assetDesktopLogoImage = ''
		assetDesktopVideoUri = 'video/Product1.mp4';
		assetVideoTitle = 'Watch HSNtv LIVE on the iPhone';
		assetVideoDescription = "Live video & shopping on your iPhone or iPod Touch.  Live encoding powered by <a href='http://www.inlethd.com/' target='_blank'>Inlet Technologies.</a>";
		assetIphoneVideoUri = '';
		assetDesktopPoster = '';
		assetDesktopThumbnail = 'video_thumb/Product1.jpg';
		assetIphoneLogoImage = 'images/logo_iphone_hsn.gif';
		assetIphonePoster = '';
		assetChannel = 'HSN';
	} else if (videoIdentifier == "T2") {
		assetDesktopLogoImage = ''
		assetDesktopVideoUri = 'video/Product2.mp4';
		assetVideoTitle = 'Watch HSNtv LIVE on the iPhone';
		assetVideoDescription = "Live video & shopping on your iPhone or iPod Touch.  Live encoding powered by <a href='http://www.inlethd.com/' target='_blank'>Inlet Technologies.</a>";
		assetIphoneVideoUri = '';
		assetDesktopPoster = '';
		assetDesktopThumbnail = 'video_thumb/Product2.jpg';
		assetIphoneLogoImage = '';
		assetIphonePoster = '';
		assetChannel = 'HSN';
	} else if (videoIdentifier == "T3") {

		assetDesktopLogoImage = ''
		assetDesktopVideoUri = 'video/Product3.mp4';
		assetVideoTitle = 'iPhone 3G-S';
		assetVideoDescription = "USA TODAY's Talking Tech with Ed Baig & Jefferson Graham: Apple announces the new iPhone 3G-S.";
		assetIphoneVideoUri = '';
		assetDesktopPoster = '';
		assetDesktopThumbnail = 'video_thumb/Product3.jpg';
		assetIphoneLogoImage = '';
		assetIphonePoster = '';
		assetChannel = 'USA Today';
	} else if (videoIdentifier == "T4") {
		assetDesktopLogoImage = ''
		assetDesktopVideoUri = 'video/Product4.mp4';
		assetVideoTitle = 'Google Maps';
		assetVideoDescription = "USA TODAY's Talking Tech with Ed Baig & Jefferson Graham: Google takes Street Maps to a new level.";
		assetIphoneVideoUri = '';
		assetDesktopPoster = '';
		assetDesktopThumbnail = 'video_thumb/Product4.jpg';
		assetIphoneLogoImage = '';
		assetIphonePoster = '';
		assetChannel = 'USA Today';
	} else if (videoIdentifier == "T5") {
		assetDesktopLogoImage = ''
		assetDesktopVideoUri = 'video/Product5.mp4';
		assetVideoTitle = 'Rupert Murdoch: Part 1';
		assetVideoDescription = 'News Corporation CEO discusses health care, taxes, jobs.';
		assetIphoneVideoUri = '';
		assetDesktopPoster = '';
		assetDesktopThumbnail = 'video_thumb/Product5.jpg';
		assetIphoneLogoImage = '';
		assetIphonePoster = '';
		assetChannel = 'Fox News';
	}

	else if (videoIdentifier == "T6") {
		assetDesktopLogoImage = ''
		assetDesktopVideoUri = 'video/Product6.mp4';
		assetVideoTitle = "Israel's Barrier";
		assetVideoDescription = "NPR's Eric Westervelt and David Gilkey traveled to Israel's West Bank barrier to explore how it has affected people on both sides.";
		assetIphoneVideoUri = '';
		assetDesktopPoster = '';
		assetDesktopThumbnail = 'video_thumb/Product6.jpg';
		assetIphoneLogoImage = '';
		assetIphonePoster = '';
		assetChannel = 'NPR';
	}

	if (1 == 2) {
		// Do nothing.
	} else if (assetId == "assetDesktopLogoImage") {
		return assetDesktopLogoImage;
	} else if (assetId == "assetDesktopVideoUri") {
		return assetDesktopVideoUri;
	} else if (assetId == "assetVideoTitle") {
		return assetVideoTitle;
	} else if (assetId == "assetVideoDescription") {
		return assetVideoDescription;
	} else if (assetId == "assetIphoneVideoUri") {
		return assetIphoneVideoUri;
	} else if (assetId == "assetDesktopPoster") {
		return assetDesktopPoster;
	} else if (assetId == "assetIphoneLogoImage") {
		return assetIphoneLogoImage;
	} else if (assetId == "assetIphonePoster") {
		return assetIphonePoster;
	} else if (assetId == "assetChannel") {
		return assetChannel;
	} else if (assetId == "assetDesktopThumbnail") {
		return assetDesktopThumbnail;
	}

	return '';

}
