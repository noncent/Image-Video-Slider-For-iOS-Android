var videoFeature;
var html5IsSupported = false;
var isiPhone = false;
var iPhoneOSMajorVersion = -1;
var isStreamingiPhone = false;
var initComplete = false;
var debugHtml = '';
var buttonEventsInitialized = false;
var desktopVideo = 'video/Product1.mp4';
var desktopTestVideo = desktopVideo;
// var desktopTestVideo =
// 'http://movies.apple.com/movies/us/apple/ipoditunes/2007/touch/ads/apple_ipodtouch_touch_r640-9cie.mov';
var iphoneVideoAssetCount = 0;
var selectedVideoToutIdSuffix = 'T1';
var legacyQuickTimePlaceholderMovie = 'video/Product1.mp4';

function init() {
	if (initComplete == true) {
		return;
	}

	var BrowserDetect = {
		init1 : function() {
			this.browser = this.searchString(this.dataBrowser)
					|| "An unknown browser";
			this.version = this.searchVersion(navigator.userAgent)
					|| this.searchVersion(navigator.appVersion)
					|| "an unknown version";
			this.OS = this.searchString(this.dataOS) || "an unknown OS";
		},
		searchString : function(data) {
			for ( var i = 0; i < data.length; i++) {
				var dataString = data[i].string;
				var dataProp = data[i].prop;
				this.versionSearchString = data[i].versionSearch
						|| data[i].identity;
				if (dataString) {
					if (dataString.indexOf(data[i].subString) != -1)
						return data[i].identity;
				} else if (dataProp)
					return data[i].identity;
			}
		},
		searchVersion : function(dataString) {
			var index = dataString.indexOf(this.versionSearchString);
			if (index == -1)
				return;
			return parseFloat(dataString.substring(index
					+ this.versionSearchString.length + 1));
		},
		dataBrowser : [ {
			string : navigator.userAgent,
			subString : "Chrome",
			identity : "Chrome"
		}, {
			string : navigator.userAgent,
			subString : "OmniWeb",
			versionSearch : "OmniWeb/",
			identity : "OmniWeb"
		}, {
			string : navigator.vendor,
			subString : "Apple",
			identity : "Safari",
			versionSearch : "Version"
		}, {
			prop : window.opera,
			identity : "Opera"
		}, {
			string : navigator.vendor,
			subString : "iCab",
			identity : "iCab"
		}, {
			string : navigator.vendor,
			subString : "KDE",
			identity : "Konqueror"
		}, {
			string : navigator.userAgent,
			subString : "Firefox",
			identity : "Firefox"
		}, {
			string : navigator.vendor,
			subString : "Camino",
			identity : "Camino"
		}, { // for newer Netscapes (6+)
			string : navigator.userAgent,
			subString : "Netscape",
			identity : "Netscape"
		}, {
			string : navigator.userAgent,
			subString : "MSIE",
			identity : "Explorer",
			versionSearch : "MSIE"
		}, {
			string : navigator.userAgent,
			subString : "Gecko",
			identity : "Mozilla",
			versionSearch : "rv"
		}, { // for older Netscapes (4-)
			string : navigator.userAgent,
			subString : "Mozilla",
			identity : "Netscape",
			versionSearch : "Mozilla"
		} ],
		dataOS : [ {
			string : navigator.platform,
			subString : "Win",
			identity : "Windows"
		}, {
			string : navigator.platform,
			subString : "Mac",
			identity : "Mac"
		}, {
			string : navigator.userAgent,
			subString : "iPhone",
			identity : "iPhone/iPod"
		}, {
			string : navigator.platform,
			subString : "Linux",
			identity : "Linux"
		} ]

	};
	BrowserDetect.init1();

	isiPhone = isiphone();
	iPhoneOSMajorVersion = getiPhoneOSMajorVersion();
	html5IsSupported = isHtml5Supported('videoelem')

	if (iPhoneOSMajorVersion >= 3) {
		isStreamingiPhone = true;
	}

	// Business Logic.
	var styleSheetRef = document.getElementById("uagentCss")

	// Set the style sheet by calling the orient event handler function
	// This will handle iphone and desktop config.
	orient();

	if (isiPhone == true) {
		// iphone.
		if (isStreamingiPhone == true) {
			// Show the iphone Video container
			showElement('videoContaineriPhone');
			initComplete = true;

			var v = 1;

			// Initialize the iphone videos.
			for (v = 1; v <= iphoneVideoAssetCount; v++) {
				var videoId = 'iVideo' + v;
				var videoUri = getVideoToutAsset('assetIphoneVideoUri', videoId);
				// Set the Title, Description, and Logo

				// Set the Videos.
				setAndPauseVideo(videoId, videoUri); // liveStreamingiPhoneVideo
				var iVideoEl = document.getElementById(videoId);
				iVideoEl.poster = getVideoToutAsset('assetIphonePoster',
						videoId);
				document.getElementById(videoId + 'Title').innerHTML = getVideoToutAsset(
						'assetVideoTitle', videoId);
				document.getElementById(videoId + 'Description').innerHTML = getVideoToutAsset(
						'assetVideoDescription', videoId);
				document.getElementById(videoId + 'Logo').src = getVideoToutAsset(
						'assetIphoneLogoImage', videoId);
			}

			// This will make sure only the seleced channels are visible;
			setVideoVisibilityByChannel();

		} else {
			// Show the Error Message.
			showElement('iphoneLegacyContainer');
		}

		// End iphone init.
	} else {
		// Desktop

		// if(BrowserDetect.browser =="Safari" && BrowserDetect.version >= "4"){
		// document.location.href="http://iphone.akamai.com/snowleopard";
		// }

		// Show the Desktop container
		showElement('videoContainer');

		var n = 1;
		var toutVideoSuffix;
		var videoToutPlayButton;
		var videoToutLogoImageId;
		var logoImage;
		var videoToutThumbImageId;
		var thumbImage;

		selectedVideoToutIdSuffix = 'T1';

		// Top Row of Video Touts
		for (n = 1; n <= 6; n++) {
			toutVideoSuffix = "T" + n;
			videoToutPlayButton = "videoToutPlayButton" + toutVideoSuffix;
			videoToutLogoImageId = "videoToutLogo" + toutVideoSuffix;
			videoToutThumbImageId = "videoToutThumbImg" + toutVideoSuffix;
			showElement(videoToutPlayButton);
			logoImage = getVideoToutAsset('assetDesktopLogoImage',
					toutVideoSuffix);
			document.getElementById(videoToutLogoImageId).src = logoImage;
			thumbImage = getVideoToutAsset('assetDesktopThumbnail',
					toutVideoSuffix);
			document.getElementById(videoToutThumbImageId).src = thumbImage;
		}

		// Bottom Row of Video Touts
		n = 1
		/*
		 * for (n = 1; n <= 6; n++) { toutVideoSuffix = "B" + n;
		 * videoToutPlayButton = "videoToutPlayButton" + toutVideoSuffix;
		 * videoToutLogoImageId = "videoToutLogo" + toutVideoSuffix;
		 * videoToutThumbImageId = "videoToutThumbImg" + toutVideoSuffix;
		 * showElement(videoToutPlayButton); logoImage =
		 * getVideoToutAsset('assetDesktopLogoImage', toutVideoSuffix);
		 * document.getElementById(videoToutLogoImageId).src = logoImage;
		 * thumbImage = getVideoToutAsset('assetDesktopThumbnail',
		 * toutVideoSuffix); document.getElementById(videoToutThumbImageId).src =
		 * thumbImage; }
		 */
		if (html5IsSupported == false) {
			// We use quick time.
			showElement('videoFeatureContainerQT');
			hideElement('videoFeatureContainer');
			registerListener('qt_ended', 'movie1', 'movie_embed1',
					quicktimeEnded);
			initComplete = true;
			showElement('videoToutSelected' + selectedVideoToutIdSuffix);
			hideElement('videoToutPlayButton' + selectedVideoToutIdSuffix);
			updateVideoToutInfo();
			// var qtMovie = getVideoToutAsset('assetDesktopVideoUri',
			// selectedVideoToutIdSuffix);
			// swapQTMovie(qtMovie)
			// alert('no html 5');
		} else {
			// We have full HTML5 Support
			hideElement('videoFeatureContainerQT');
			showElement('videoFeatureContainer');

			videoFeature = document.getElementById('videoelem');
			initComplete = true;

			// Set up the controls by triggering stoppedPlaying;
			stoppedPlaying();

			// We'll start by initializing the first video tout without Playing
			// it.
			videoFeature.poster = getVideoToutAsset('assetDesktopPoster',
					selectedVideoToutIdSuffix);
			showElement('videoToutSelected' + selectedVideoToutIdSuffix);
			hideElement('videoToutPlayButton' + selectedVideoToutIdSuffix);
			addEventListenersToControls();
			updateVideoToutInfo();
		}

		// End Desktop init.
	}

	initComplete == true
	// alert('init complete');
}

function playAlert() {
	// alert('played alert');
}